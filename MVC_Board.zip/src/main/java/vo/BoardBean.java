package vo;

public class BoardBean {

}

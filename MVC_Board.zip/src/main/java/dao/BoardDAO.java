package dao;

import java.sql.Connection;

public class BoardDAO {
	// 싱글톤 디자인 패턴을 활용한 BoardDAO 인스턴스 관리
	private BoardDAO() {}
	
	private static BoardDAO instance = new BoardDAO();

	public static BoardDAO getInstance() {
		return instance;
	}
	
	// ----------------------------------------------------------------------
	// 외부(Service)로부터 Connection 객체를 전달받아 멤버변수 con 에 저장
	private Connection con;

	public void setConnection(Connection con) {
		this.con = con;
	}
	// ----------------------------------------------------------------------
	
	
	
}














